<?php

error_reporting(0);

error_reporting(E_ALL ^ E_NOTICE);

// phpBB 3.0.x auto-generated configuration file
// Do not change anything in this file!
$dbms = 'mysql';
$dbhost = 'localhost';
$dbport = '';
$dbname = 'appasaule';
$dbuser = 'MPS';
$dbpasswd = '';
$table_prefix = 'phpbb_';
$acm_type = 'file';
$load_extensions = '';

@define('PHPBB_INSTALLED', true);
@define('DEBUG', false);
 @define('DEBUG_EXTRA', true);
?>