<?php


$s = $_SERVER['SERVER_NAME'];

define("BASE", "/");
define("BASE_URL", "http://www.appasaule.lv/");

define("DB_HOST", "localhost");
define("DB_USER", "MPS");
define("DB_PASS", "");
define("DB_NAME", "appasaule");

//if(!preg_match('/^www/', $_SERVER['SERVER_NAME'])) {
//	header('Location: ' . BASE_URL);
//}

?>
