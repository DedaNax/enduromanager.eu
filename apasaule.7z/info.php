<?php



echo phpinfo();

?>