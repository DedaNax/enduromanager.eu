Galerija

Tabulas: galery_list un galery_images izveidojas pasas, pirmo reizi palaizot 
administrativo moduli.

Ja mainaas tacinja, db connections to mainaam mysql.php
Defaulti bildes sakriit /img, pamatkalatogaa

/admin/editor/dialogs
* fck_link.html
* fck_link/fck_link.js

/
* galery.php
* gimage.php

/admin/editor/galery/
* add_picture.php
* ajax.js
* ajax.php
* class.php
* fp.gif
* image.php
* index.php
* loading.gif
* mysql.php
* _readme.txt
* reload.gif
* small.gif
