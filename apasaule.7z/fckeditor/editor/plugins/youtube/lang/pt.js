/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: pt.js
 * 	Portuguese language file for the youtube plugin.
 * 
 * File Authors:
 * 		Ivo Emanuel Gonçalves (justivo (at) gmail.com) 2009/01/19
 */

FCKLang['YouTubeTip']			= 'Inserir/Editar YouTube' ;
FCKLang['DlgYouTubeTitle']		= 'Propriedade YouTube' ;
FCKLang['DlgYouTubeCode']		= '"Por favor insira o endereço do video YouTube."' ;
FCKLang['DlgYouTubeSecurity']	= 'Endereço inválido.' ;
FCKLang['DlgYouTubeURL']	    = 'Endereço' ;
FCKLang['DlgYouTubeWidth']	    = 'Largura' ;
FCKLang['DlgYouTubeHeight']	    = 'Altura' ;
FCKLang['DlgYouTubeQuality']    = 'Qualidade' ;
FCKLang['DlgYouTubeLow']	    = 'Baixa' ;
FCKLang['DlgYouTubeHigh']	    = 'Alta (se disponível)' ;
