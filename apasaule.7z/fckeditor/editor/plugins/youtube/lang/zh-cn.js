/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: zh-cn.js
 * 	Chinese(simplify) language file for the youtube plugin.
 * 
 * File Authors:
 * 		Uprush (uprushworld@yahoo.co.jp) 2008/03/22
 */

FCKLang['YouTubeTip']			= 'YouTube插入/编辑' ;
FCKLang['DlgYouTubeTitle']		= 'YouTube属性' ;
FCKLang['DlgYouTubeCode']		= '请插入 YouTube 动画的URL。' ;
FCKLang['DlgYouTubeSecurity']	= '不正确的URL。' ;
FCKLang['DlgYouTubeURL']	    = 'URL' ;
FCKLang['DlgYouTubeWidth']	    = '宽' ;
FCKLang['DlgYouTubeHeight']	    = '高' ;
FCKLang['DlgYouTubeQuality']    = '画质' ;
FCKLang['DlgYouTubeLow']	    = '低' ;
FCKLang['DlgYouTubeHigh']	    = '高 (如果可能)' ;
