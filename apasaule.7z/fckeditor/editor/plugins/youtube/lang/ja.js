/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: ja.js
 * 	Japanese language file for the youtube plugin.
 * 
 * File Authors:
 * 		Uprush (uprushworld@yahoo.co.jp) 2007/10/30
 */

FCKLang['YouTubeTip']			= 'YouTube挿入/編集' ;
FCKLang['DlgYouTubeTitle']		= 'YouTubeプロパティ' ;
FCKLang['DlgYouTubeCode']	    = 'URLを挿入してください。' ;
FCKLang['DlgYouTubeSecurity']	= 'URLが正しくありません。' ;
FCKLang['DlgYouTubeURL']	    = 'URL' ;
FCKLang['DlgYouTubeWidth']	    = '幅' ;
FCKLang['DlgYouTubeHeight']	    = '縦' ;
FCKLang['DlgYouTubeQuality']    = '画質' ;
FCKLang['DlgYouTubeLow']	    = '低' ;
FCKLang['DlgYouTubeHigh']	    = '高（可能であれば）' ;
