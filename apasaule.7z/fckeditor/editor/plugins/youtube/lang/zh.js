﻿/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: ja.js
 * 	English language file for the youtube plugin.
 * 
 * File Authors:
 * 		Uprush (uprushworld@yahoo.co.jp) 2007/10/30
 */

FCKLang['YouTubeTip']			= '插入YouTube網址' ;
FCKLang['DlgYouTubeTitle']		= 'YouTube內容' ;
FCKLang['DlgYouTubeCode']		= '"請插入/貼上YouTube影片連結網址"' ;
FCKLang['DlgYouTubeSecurity']	= '不合法的連結網址' ;
FCKLang['DlgYouTubeURL']	    = '貼上YouTube連結網址' ;
FCKLang['DlgYouTubeWidth']	    = '寬度' ;
FCKLang['DlgYouTubeHeight']	    = '高度' ;
FCKLang['DlgYouTubeQuality']    = '影片品質' ;
FCKLang['DlgYouTubeLow']	    = '低' ;
FCKLang['DlgYouTubeHigh']	    = '高 (如果有提供)' ;
